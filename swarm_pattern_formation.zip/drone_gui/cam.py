import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
bridge = CvBridge()
temp=0
import os
def image_callback(msg):
    global temp
    if temp==0:
        print("Received an image!")
        cv2_img = bridge.imgmsg_to_cv2(msg, "bgr8")
        cv2.imshow('Camera of drone 6', cv2_img)
        if cv2.waitKey(10)==113:
            cv2.destroyAllWindows()
            temp=1
            quit()
def main(cam):
	rospy.init_node('image_listener')
	image_topic =cam
	rospy.Subscriber(image_topic, Image, image_callback)
	

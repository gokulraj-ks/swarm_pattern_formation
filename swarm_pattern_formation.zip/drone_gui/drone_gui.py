import os
import eel
import cam
eel.init('web')
import multiprocessing 
import time
def d1(): 
	os.system("roslaunch hector_quadrotor_demo all.launch")
def d2(): 
	os.system("python ser.py")

def d3(): 
	os.system("python draw.py")

@eel.expose
def a():
	cam.main("/uav1/front_cam/camera/image")
@eel.expose
def b():
	cam.main("/uav2/front_cam/camera/image")
@eel.expose
def c():
	cam.main("/uav3/front_cam/camera/image")
@eel.expose
def d():
	cam.main("/uav4/front_cam/camera/image")
@eel.expose
def e():
	cam.main("/uav5/front_cam/camera/image")
@eel.expose
def f():
	cam.main("/uav6/front_cam/camera/image")
@eel.expose
def g():
	cam.main("/uav7/front_cam/camera/image")
@eel.expose
def h():
	cam.main("/uav8/front_cam/camera/image")
@eel.expose
def i():
	cam.main("/uav9/front_cam/camera/image")
@eel.expose
def j():
	cam.main("/uav10/front_cam/camera/image")
@eel.expose
def k():
	cam.main("/uav11/front_cam/camera/image")
@eel.expose
def l():
	cam.main("/uav12/front_cam/camera/image")
@eel.expose
def launch():
	p1 = multiprocessing.Process(target=d1) 
	p1.start()
	p1.join()

@eel.expose
def start():
	p2 = multiprocessing.Process(target=d2)
	p2.start()
	p2.join()

@eel.expose
def draw():
	p3 = multiprocessing.Process(target=d3)
	p3.start()
	p3.join()


eel.start('main.html', size=(1200, 600))

#!/usr/bin/env python

import rospy
import copy
from geometry_msgs.msg import Twist, PoseStamped

def call(data):
    global msg
    global error
    global error_prev
    global arrived
    global point
    global drone
    print(drone)
    kp = [1.0, 1.0, 1.2] 
    kd = [0.2, 0.2, 0.3]
    ki = [0.0001, 0.0001, 0.0001]
    rospy.loginfo([data.pose.position.x, data.pose.position.y, data.pose.position.z])
    error_current = [round(point[0] - data.pose.position.x, 2), round(point[1] - data.pose.position.y, 2), round(point[2] - data.pose.position.z, 2)]
    for i in range(len(error)):
        error[i] += error_current[i]
    if ((error_current[0] < 0.2) and (error_current[0] > -0.2)) and ((error_current[1] < 0.2) and (error_current[1] > -0.2)) and ((error_current[2] < 0.2) and (error_current[2] > -0.2)):
        arrived = True
    integral = ki[2] * error[2]
    if arrived == False:
        msg.linear.x = (kp[0] * error_current[0]) + ki[0] * error[0] + (kd[0] * (error_current[0] - error_prev[0]))
        msg.linear.y = (kp[1] * error_current[1]) + ki[1] * error[1] + (kd[1] * (error_current[1] - error_prev[1]))
        msg.linear.z = (kp[2] * error_current[2]) + integral + (kd[2] * (error_current[2] - error_prev[2]))
    elif arrived == True:
        msg.linear.x = 0
        msg.linear.y = 0
        msg.linear.z = 0
    if (msg.linear.z > 1):
        msg.linear.z = 1.5
    if (msg.linear.y > 1):
        msg.linear.y = 1.5
    if (msg.linear.x > 1):
        msg.linear.x = 1.5
    if (msg.linear.x < -1):
        msg.linear.x = -1.5
    if (msg.linear.y < -1):
        msg.linear.y = -1.5
    if (msg.linear.z < -1):
        msg.linear.z = -1.5
    pub = rospy.Publisher('uav'+drone+'/cmd_vel', Twist, queue_size=10)
    pub.publish(msg)
    # Resetting prev_error
    error_prev = copy.deepcopy(error_current)


def hector():
    rospy.init_node('test', anonymous=True)
    global msg
    global error
    global error_prev
    global arrived
    global drone
    print(drone)
    arrived = False
    error_prev = [0, 0, 0]
    msg = Twist()
    error = [0, 0, 0]

    rospy.Subscriber('uav'+drone+'/ground_truth_to_tf/pose', PoseStamped, call)
    
    rate = rospy.Rate(30)  # 30hz
    rospy.spin()
def fly(d,p):
	global drone
	global point
	#print(drone)
	drone=str(d)
	point=p
	hector()



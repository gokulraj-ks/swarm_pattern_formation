import os
os.system(' rosservice call /uav1/enable_motors "enable: true"')
os.system(' rosservice call /uav2/enable_motors "enable: true"')
os.system(' rosservice call /uav3/enable_motors "enable: true"')
os.system(' rosservice call /uav4/enable_motors "enable: true"')
os.system(' rosservice call /uav5/enable_motors "enable: true"')
os.system(' rosservice call /uav6/enable_motors "enable: true"')
os.system(' rosservice call /uav7/enable_motors "enable: true"')
os.system(' rosservice call /uav8/enable_motors "enable: true"')
os.system(' rosservice call /uav9/enable_motors "enable: true"')
os.system(' rosservice call /uav10/enable_motors "enable: true"')
os.system(' rosservice call /uav11/enable_motors "enable: true"')
os.system(' rosservice call /uav12/enable_motors "enable: true"')


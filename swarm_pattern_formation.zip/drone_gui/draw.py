import control1
import multiprocessing 
import time
import cv2
from scipy.interpolate import interp1d 
import sys
count=0
points=[]
gpoints=[]
number_of_drones=13
yes=0
no=0
def d1(poy,pox): 
  control1.fly(1,[pox,poy,13])
def d2(poy,pox): 
  control1.fly(2,[pox,poy,13])
def d3(poy,pox): 
  control1.fly(3,[pox,poy,13])
def d4(poy,pox): 
  control1.fly(4,[pox,poy,13])
def d5(poy,pox): 
  control1.fly(5,[pox,poy,13])
def d6(poy,pox): 
  control1.fly(6,[pox,poy,13])
def d7(poy,pox): 
  control1.fly(7,[pox,poy,13])
def d8(poy,pox): 
  control1.fly(8,[pox,poy,13])
def d9(poy,pox): 
  control1.fly(9,[pox,poy,13])
def d10(poy,pox): 
  control1.fly(10,[pox,poy,13])
def d11(poy,pox): 
  control1.fly(11,[pox,poy,13])
def d12(poy,pox): 
  control1.fly(12,[pox,poy,13])

def goal(points):
	global gpoints
	a=1
	print("d")
	for i in gpoints:
		print(a,i)
		a=a+1
	p1 = multiprocessing.Process(target=d1, args=(gpoints[0][0],gpoints[0][1], )) 
	p2 = multiprocessing.Process(target=d2, args=(gpoints[1][0],gpoints[1][1], )) 
	p3= multiprocessing.Process(target=d3, args=(gpoints[2][0],gpoints[2][1], )) 
	p4 = multiprocessing.Process(target=d4, args=(gpoints[3][0],gpoints[3][1], )) 
	p5 = multiprocessing.Process(target=d5, args=(gpoints[4][0],gpoints[4][1], )) 
	p6 = multiprocessing.Process(target=d6, args=(gpoints[5][0],gpoints[5][1], )) 
	p7 = multiprocessing.Process(target=d7, args=(gpoints[6][0],gpoints[6][1], )) 
	p8 = multiprocessing.Process(target=d8, args=(gpoints[7][0],gpoints[7][1], )) 
	p9 = multiprocessing.Process(target=d9, args=(gpoints[8][0],gpoints[8][1], )) 
	p10 = multiprocessing.Process(target=d10, args=(gpoints[9][0],gpoints[9][1], )) 
	p11 = multiprocessing.Process(target=d11, args=(gpoints[10][0],gpoints[10][1], )) 
	p12 = multiprocessing.Process(target=d12, args=(gpoints[11][0],gpoints[11][1], ))
	
	p1.start()
	time.sleep(2)

	p2.start() 
	time.sleep(2)

	p3.start() 
	time.sleep(2)

	p4.start() 
	time.sleep(2)

	p5.start() 
	time.sleep(2)

	p6.start() 
	time.sleep(2)

	p7.start() 
	time.sleep(2)

	p8.start() 
	time.sleep(2)

	p9.start() 

	time.sleep(2)

	p10.start() 

	time.sleep(2)

	p11.start() 

	time.sleep(1)

	p12.start() 
	p1.join() 

	p2.join() 

	p3.join() 

	p4.join() 

	p5.join() 

	p6.join() 

	p7.join() 

	p8.join() 


	p9.join() 

	p10.join() 

	p11.join() 

	p12.join() 


	while 1:
		if(cv2.waitKey(10)==97):
			print("Ending......//////")
			sys.exit()

		
def click_event(event, x, y, flags, params):
	global count 
	global points
	global gpoints
	xv = interp1d([0,498],[-10,10])
	yv = interp1d([0,511],[-10,10])
	if event == cv2.EVENT_LBUTTONDOWN and count<number_of_drones:
		no=0
		for i in points:
			if (( i[0]-x) * ( i[0]-x) +( i[1]-y) * ( i[1]-y) <= 500):
				no=1
				
				print("please choose other point. The points"+"("+str(i[0]),str(i[1])+")"+"("+str(x),str(y)+")"+" are near")
				warning=cv2.imread("war.jpg")
				cv2.imshow("warning",warning)
				cv2.waitKey(2500)
				cv2.destroyWindow('warning')
			else:
				yes=1
				
				
		if no == 0:
			points.append((x,y)) 
			gpoints.append((round(float(xv(x)),3),round(float(yv(y)),3)))
			#print(gpoints)
			font = cv2.FONT_HERSHEY_SIMPLEX 
			cv2.circle(img, (x,y), 1,(0,0,255) ,3) 
			cv2.circle(img, (x,y), 3,(80,0,0) ,2)
			cv2.circle(img, (x,y), 10,(0,0,170) ,2)		
			cv2.circle(img, (x,y), 17,(0,0,220) ,2)
			cv2.circle(img, (x,y), 23,(80,0,0) ,1)
			#print(count-1,count)
			cv2.line(img, points[count-1], points[count], (0,105,0), 1)
			cv2.imshow('Swarm formation', img)
			count=count+1
			if count==number_of_drones:
				goal(points)
	
if __name__=="__main__": 
	img = cv2.imread('gazebo.jpg', 1) 
	#print(img.shape)
	cv2.imshow('Swarm formation', img)  
	cv2.setMouseCallback('Swarm formation', click_event) 
	cv2.waitKey(0)

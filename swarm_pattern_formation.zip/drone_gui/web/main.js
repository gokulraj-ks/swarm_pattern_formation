function line() {
	eel.line()
}

function square() {
	eel.square()
}

function rect() {
	eel.rect()
}

function tri() {
	eel.tri()
}

function a() {
	eel.a()
}
function b() {
	eel.b()
}
function c() {
	eel.c()
}
function d() {
	eel.d()
}
function e() {
	eel.e()
}
function f() {
	eel.f()
}
function g() {
	eel.g()
}
function h() {
	eel.h()
}
function i() {
	eel.i()
}
function j() {
	eel.a()
}
function k() {
	eel.k()
}



function launch() {
	eel.launch()
}

function draw() {
	eel.draw()
}


function octogon() {
	eel.octogon()
}

function hexagon() {
	eel.hexagon()
}

function eight() {
	eel.eight()
}

function star2() {
	eel.star2()
}

function start() {
	eel.start()
}
